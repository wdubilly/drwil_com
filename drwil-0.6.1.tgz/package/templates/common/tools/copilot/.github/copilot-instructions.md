Read and apply `AGENTS.md` at the repository root, then the `AGENTS.md` of the layer you touch. This file only points to them.

An identifier cited to a human (contract ID, catalog line, lot or point of a brief) is always followed by what it designates; its label: `node .githooks/glossary.mjs "<text>"`.
