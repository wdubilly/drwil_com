# Recipe: create a release (tag + GitHub note)

Goal: mark a merged workstream with a Git tag (`vX.Y.Z`) and a release
note, without publishing to npm and without committing any file
(compatible with a "no direct commit on the main branch" contract, if
adopted).

This is **not installed by default**: the script that computes and posts
the release is an optional module, like the dashboard — see the README
in `templates/common/optional/create-release/` (module shipped by the
kit package) to activate it, copied to
`.githooks/create-release.mjs` (to create). Like a commit or a push, this
script only runs on the user's explicit request, never on its own in CI.

## Method (once the module is activated)

1. Preview without creating anything: `node .githooks/create-release.mjs
   --dry-run` — shows the last tag, the detected bump (major/minor/patch)
   and the next version.
2. The version: when there are publishable npm packages (tracked
   package.json, with a `name`, without `"private": true`), the tag is
   **`v` + their `version`** — single source, decided in a PR with
   `npm version patch|minor|major --no-git-tag-version`. The script refuses
   (exit 1, `--dry-run` included) a tag that already exists, a version that
   does not increase, or packages that disagree. Without an npm package,
   the version is computed *best-effort* from commit messages since the
   last tag, Conventional-Commits style (`feat:` → minor, announced
   breaking change → major, otherwise patch by default); with packages,
   that computation is only a displayed suggestion. In the same PR, if the
   project keeps a `CHANGELOG.md` (if present), its « Unreleased » section, fed by each
   workstream's closing, is renamed to that version (a new empty
   « Unreleased » above it).
3. Create for real: `node .githooks/create-release.mjs` (annotated tag
   pushed to `origin`, then `gh release create --generate-notes` if `gh`
   is available and authenticated).
4. If the repo contains one or more publishable npm packages (a
   `package.json`, if present, tracked by Git, with a `name`, without
   `"private": true`), a tarball (`npm pack`) is built for each and
   attached as a downloadable asset on the GitHub release — handy to
   hand the package to someone to try without publishing to npm.
   `--dry-run` lists the packages that would be packed without
   building anything.
5. Wrong version for once (miscalculated tag): delete the tag (`git tag
   -d vX.Y.Z && git push origin :refs/tags/vX.Y.Z`) and rerun once the
   fix is in place — never rewrite shared history.

## Assumed limits

- Designed for GitHub (`gh release create`); on GitLab, only the Git tag
  is posted by the script, the release note still needs to be created
  via the GitLab Releases API (best-effort, not covered).
- Never publishes to npm: a separate decision, out of scope for this
  recipe.
