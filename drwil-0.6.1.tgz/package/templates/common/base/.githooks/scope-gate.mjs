#!/usr/bin/env node
// Scope gate (docs/ia-first.md, "Scope gate"), the engine's "scope-gate" check
// (.githooks/engine.mjs): commit, push, CI, `drwil verify`.
//
// - Briefs (docs/projects/, docs/intentions/…) can always be committed.
// - At commit time, any other file requires the BUILD activity and must be covered by the
//   scope block of the active brief as it is in HEAD: widening its scope takes a separate
//   commit, visible on its own.
// - Elsewhere (pre-push, CI, verify), there is no local state: each commit of the branch is
//   replayed against the scope of the brief named by its `Drwil-Brief` trailer, read in its
//   parent. A commit is judged by its parent's rules: without a gate in the parent, it is not
//   checked.
// Severity: `scopeGate` setting (off | warning | blocking), warning if missing.
import { spawnSync } from "node:child_process";
import { pathToFileURL } from "node:url";
import { fnmatch, normalize, readBlock, withMirrors } from "./scope.mjs";
import { governanceDisabled, readState } from "./state.mjs";

// Attestations pass like briefs: a human proof already guarded by `drwil attest` (terminal
// required, contract fingerprint), reviewed; subjecting them to the scope would force widening
// every brief in order to close. The consumption log likewise: its line is written in CLOSING,
// for the closing commit (`consumption.mjs --record`).
export const OUT_OF_SCOPE = ["docs/projects/*", "docs/intentions/*", ".drwil/evidence/attestations/*", ".drwil/usage.jsonl"];
export const TRAILER = "Drwil-Brief";
const LEVELS = new Set(["off", "warning", "blocking"]);
const MARKER = ".githooks/scope-gate.mjs";

const TEXTS = {
  fr: {
    activity: (a, n) =>
      `${n} fichier(s) hors fiches commité(s) en ${a} : seule l'activité BUILD l'autorise (node .githooks/state.mjs move …)`,
    outsideScope: (f, brief) => `${f} : hors du cadrage de ${brief} (dans HEAD) — l'ajouter au bloc scope et commiter la fiche d'abord`,
    noTrailer: (c, n) => `${c} : ${n} fichier(s) hors fiches sans trailer ${TRAILER}`,
    outsideScopeCommit: (c, f, brief) => `${c} : ${f} hors du cadrage de ${brief} (dans le parent)`,
    noReference: "aucune branche de référence (origin/HEAD, master, main, ou DRWIL_BASE)",
    failed: (n) => `périmètre de l'attente : ${n} problème(s) (barrière bloquante)`,
  },
  en: {
    activity: (a, n) =>
      `${n} file(s) outside briefs committed in ${a}: only the BUILD activity allows it (node .githooks/state.mjs move …)`,
    outsideScope: (f, brief) => `${f}: outside the scope of ${brief} (in HEAD) — add it to the scope block and commit the brief first`,
    noTrailer: (c, n) => `${c}: ${n} file(s) outside briefs without a ${TRAILER} trailer`,
    outsideScopeCommit: (c, f, brief) => `${c}: ${f} outside the scope of ${brief} (in the parent)`,
    noReference: "no reference branch (origin/HEAD, master, main, or DRWIL_BASE)",
    failed: (n) => `brief scope: ${n} problem(s) (blocking gate)`,
  },
};

const texts = (cfg) => TEXTS[cfg?.lang === "en" ? "en" : "fr"];

function git(root, args) {
  const r = spawnSync("git", args, { cwd: root, encoding: "utf8" });
  return r.status === 0 ? r.stdout : null;
}

/** Files subject to the scope: everything but briefs (configurable list). */
export function outsideBriefFiles(files, outOfScope = OUT_OF_SCOPE) {
  return files.map(normalize).filter((f) => !outOfScope.some((p) => fnmatch(f, p)));
}

const covered = (f, patterns) => patterns.some((p) => fnmatch(f, p));

/** Problems of a commit being prepared (pure). */
export function checkIndex({ files, state, patterns, outOfScope, cfg }) {
  const T = texts(cfg);
  const subject = outsideBriefFiles(files, outOfScope);
  if (!subject.length) return [];
  if (state.activity !== "BUILD") return [T.activity(state.activity, subject.length)];
  return subject.filter((f) => !covered(f, patterns)).map((f) => T.outsideScope(f, state.active_brief));
}

/** Patterns of the scope block of `brief` in revision `rev`, copies included; none if the brief does not exist there. */
function patternsAt(root, rev, brief, cfg) {
  const text = brief ? git(root, ["show", `${rev}:${brief}`]) : null;
  return text === null ? [] : withMirrors(readBlock(text).patterns, cfg);
}

function reference(root, env) {
  const candidates = env.DRWIL_BASE ? [env.DRWIL_BASE] : [];
  const origin = git(root, ["symbolic-ref", "--quiet", "refs/remotes/origin/HEAD"]);
  if (origin) candidates.push(origin.trim());
  candidates.push("origin/master", "origin/main", "master", "main");
  for (const ref of candidates) {
    if (git(root, ["rev-parse", "--verify", "--quiet", `${ref}^{commit}`]) === null) continue;
    const base = git(root, ["merge-base", "HEAD", ref]);
    if (base) return base.trim();
  }
  return null;
}

function checkBranch(root, base, { outOfScope, cfg }) {
  const T = texts(cfg);
  const problems = [];
  // No `?? ""` fallback on these git calls: they work on existing commits (base from merge-base);
  // a failure must break the check, not let it pass without judging anything (QUA-013).
  const commits = git(root, ["rev-list", "--no-merges", "--reverse", `${base}..HEAD`])
    .split("\n")
    .filter(Boolean);
  for (const c of commits) {
    const short = c.slice(0, 7);
    // The parent's rules: without a gate in the parent, the commit is not judged.
    if (git(root, ["cat-file", "-e", `${c}^:${MARKER}`]) === null) continue;
    const files = git(root, ["diff-tree", "--no-commit-id", "--name-only", "-r", "--no-renames", c]).split("\n").filter(Boolean);
    const subject = outsideBriefFiles(files, outOfScope);
    if (!subject.length) continue;
    const values = git(root, ["log", "-1", `--format=%(trailers:key=${TRAILER},valueonly)`, c])
      .split("\n")
      .map((v) => v.trim())
      .filter(Boolean);
    const brief = values.at(-1);
    if (!brief) {
      problems.push(T.noTrailer(short, subject.length));
      continue;
    }
    const patterns = patternsAt(root, `${c}^`, brief, cfg);
    for (const f of subject) if (!covered(f, patterns)) problems.push(T.outsideScopeCommit(short, f, brief));
  }
  return problems;
}

/**
 * Full check for the engine: `{ status, problems, message?, detail? }`.
 * `staged` (staged files) is only given at pre-commit; otherwise the branch is replayed.
 */
export function checkScope(root, { cfg = {}, staged = null, env = process.env } = {}) {
  const level = LEVELS.has(cfg.scopeGate) ? cfg.scopeGate : "warning";
  if (level === "off") return { status: "not-applicable", problems: [], detail: "scopeGate: off" };
  const outOfScope = Array.isArray(cfg.outOfScope) ? cfg.outOfScope : OUT_OF_SCOPE;
  let problems;
  if (staged) {
    const { state } = readState(root);
    problems = checkIndex({ files: staged, state, patterns: patternsAt(root, "HEAD", state.active_brief, cfg), outOfScope, cfg });
  } else {
    const base = reference(root, env);
    if (!base) return { status: "not-run", problems: [], detail: texts(cfg).noReference, configured: true };
    problems = checkBranch(root, base, { outOfScope, cfg });
  }
  if (problems.length && level === "blocking") return { status: "fail", problems, message: texts(cfg).failed(problems.length) };
  return { status: "ok", problems };
}

/** Adds `Drwil-Brief: <active brief>` to the message (prepare-commit-msg hook); nothing without a brief or governance. */
export function addTrailer(root, messageFile) {
  if (governanceDisabled(root)) return;
  const { state } = readState(root);
  if (!state.active_brief) return;
  git(root, ["interpret-trailers", "--in-place", "--if-exists", "replace", "--trailer", `${TRAILER}: ${state.active_brief}`, messageFile]);
}

// `node .githooks/scope-gate.mjs --trailer <file>` (prepare-commit-msg). Never blocks the commit:
// addTrailer does not throw, a git failure leaves the message as it is.
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const i = process.argv.indexOf("--trailer");
  if (i >= 0 && process.argv[i + 1]) addTrailer(process.cwd(), process.argv[i + 1]);
}
